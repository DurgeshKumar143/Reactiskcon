let words=document.querySelectorAll(".word")
words.forEach((word)=>{
    let letters=word.textContent.split("");
    word.textContent="";
    letters.forEach((letter)=>{
        let span=document.createElement("span");
        span.textContent=letter;
        span.className="letter";
        word.appendChild(span);
    })
});

let currentWordIndex=0;
let maxWordIndex=words.length-1;
words[currentWordIndex].style.opacity="1"

let changeText=()=>{
    let currentWord=words[currentWordIndex];
    let nextWord=currentWordIndex===maxWordIndex?words[0]:words[currentWordIndex+1];
    Array.from(currentWord.children).forEach((letter,i)=>{
        setTimeout(()=>{
            letter.className="letter out";
        },i*80)

    })
    nextWord.style.opacity="1";
    Array.from(nextWord.children).forEach((letter,i)=>{
        letter.className="letter behind";
        setTimeout(()=>{
            letter.className="letter in";
        },340+i*80)
    })

    currentWordIndex=currentWordIndex===maxWordIndex? 0:currentWordIndex+1;
};

changeText()
setInterval(changeText,3000)



// This is window scroll script

 

// circle skill

const circles=document.querySelectorAll(".circle");
circles.forEach(elem=>{
    var dots=elem.getAttribute("data-dots");
    var marked=elem.getAttribute("data-percent");
    var percent=Math.floor(dots*marked/100);
    var points=" ";
    var rotate=360/dots;
    for(let i=0;i<dots;i++){
        points+=`<div class="points scroll-width" style="--i:${i}; --rot:${rotate}deg"></div>`
    }
    elem.innerHTML=points;
    // elem.innerHTML=scroll-width;

    const pointsMarked=elem.querySelectorAll(".points");
    for(let i=0;i<percent;i++){
        pointsMarked[i].classList.add("marked")
    }
})


 




// active menu bar

// let menuLi=document.querySelectorAll('header ul li a');
// let section =document.querySelectorAll('section');


// function activeMenu(){
//     let len =section.length;
//     while(--len && window.scrollY + 97 <section[len].offsetTop){}
//         menuLi.forEach(sec=>sec.classList.remove("active"));
//         menuLi[len].classList.add('active');
    

// }
// activeMenu();
// window.addEventListener('scroll', activeMenu);


const li = document.querySelectorAll('.manu-btn');
const sec = document.querySelectorAll('section');

function activeMenu(){
  let len=sec.length;
  while(--len && window.scrollY +215 <sec [len].offsetTop){}
  li.forEach(ltx => ltx.classList.remove("active"));
  li[len].classList.add("active");

}
activeMenu();
window.addEventListener("scroll",activeMenu);




// sticky nav bar
const header=document.querySelector('header');
window.addEventListener("scroll",function(){
    header.classList.toggle("sticky",window.scrollY >50);
})



function sendEmail(){
    const name=document.getElementById("name").value;
    const email=document.getElementById("email").value;
    const address=document.getElementById("address").value;
    const phone=document.getElementById("phone").value;
    const msg=document.getElementById("msg").value;
    const sub=document.getElementById("sub").value;
   
    Email.send({
        SecureToken : "82afdd3d-6275-4420-bf60-4930b714be42",
        To : 'mithileshk50331@gmail.com',
        From : "durgeshk503331@gmail.com",
        Subject :  `${sub}`,
        // Body : "Name:"+<b>name</b>+""
        // Body : `<b>Name</b> ${name} <br>and my email is <b> ${email} </b> my phone number is ${phone} i am From: ${address}<br/> <b>Message:</b>${msg}`
        Body:`<b>Name:</b>${name}<br/><b>Email:</b>${email}<br/><b>Phone:</b>${phone}<br/><b>Address:</b>${address}<br/> <b>Messege: </b><br> <pre>                 <big>${msg}</big></pre>`
         
    }).then(
      message => alert(message)
    );
}


// (setInterval(()=>{
//     setTimeout(()=>{
//         document.title=`New message`

//     },1000)
//     setTimeout(()=>{
//         document.title="Welcome ! Durgesh"

//     },1500)

// },1000))



function tgl(){
let menuIcon=document.querySelector("#menu-icon")
let navlist=document.querySelector(".navlist");
    navlist.classList.toggle("active")
    window.addEventListener("click",function(e){
        if(!menuIcon.contains(e.target))
        navlist.classList.remove("active")
    })
}


const observer=new IntersectionObserver((entries)=>{
    entries.forEach((entry)=>{
        if(entry.isIntersecting){
            entry.target.classList.add("show-items")
        }else{
            entry.target.classList.remove("show-items")
        }
    })
});

const scrollScale=document.querySelectorAll(".scroll-scale");
scrollScale.forEach((el)=>observer.observe(el));

const scrollBottom=document.querySelectorAll(".scroll-bottom");
scrollBottom.forEach((el)=>observer.observe(el));

const scrollTop=document.querySelectorAll(".scroll-top");
scrollTop.forEach((el)=>observer.observe(el));


const scrollWith=document.querySelectorAll(".scroll-width");
scrollWith.forEach((el)=>observer.observe(el));
 